package com.example.ca216oct
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import android.content.Context
import android.provider.BaseColumns

class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: LoanTrackerDbHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nameEditText: EditText = findViewById(R.id.nameEditText)
        val loanTypeRadioGroup: RadioGroup = findViewById(R.id.loanTypeRadioGroup)
        val loanTypeDetailsRadioGroup: RadioGroup = findViewById(R.id.loanTypeDetailsRadioGroup)
        val loanAmountEditText: EditText = findViewById(R.id.loanAmountEditText)
        val submitButton: Button = findViewById(R.id.submitButton)

        dbHelper = LoanTrackerDbHelper(this)

        submitButton.setOnClickListener {
            val name = nameEditText.text.toString()
            val selectedLoanType = findViewById<RadioButton>(loanTypeRadioGroup.checkedRadioButtonId).text.toString()
            val selectedLoanTypeDetails = findViewById<RadioButton>(loanTypeDetailsRadioGroup.checkedRadioButtonId).text.toString()
            val loanAmount = loanAmountEditText.text.toString()

            // Store the data in SQLite database
            val db: SQLiteDatabase = dbHelper.writableDatabase
            val values = ContentValues().apply {
                put(LoanTrackerContract.LoanEntry.COLUMN_NAME, name)
                put(LoanTrackerContract.LoanEntry.COLUMN_LOAN_TYPE, selectedLoanType)
                put(LoanTrackerContract.LoanEntry.COLUMN_LOAN_TYPE_DETAILS, selectedLoanTypeDetails)
                put(LoanTrackerContract.LoanEntry.COLUMN_LOAN_AMOUNT, loanAmount)
            }
            db.insert(LoanTrackerContract.LoanEntry.TABLE_NAME, null, values)

            // Print the receipt
            printReceipt(name, selectedLoanType, selectedLoanTypeDetails, loanAmount)
        }
    }

    private fun printReceipt(name: String, selectedLoanType: String, selectedLoanTypeDetails: String, loanAmount: String) {
        val receipt = "Name: $name\nLoan Type: $selectedLoanType\nLoan Type Details: $selectedLoanTypeDetails\nLoan Amount: $loanAmount"
        Toast.makeText(this, receipt, Toast.LENGTH_LONG).show()

        val emi = calculateEMI(loanAmount.toDouble(), getInterestRate(selectedLoanTypeDetails), getTenure(selectedLoanTypeDetails))
        val emiMessage = "EMI: $emi"
        Toast.makeText(this, emiMessage, Toast.LENGTH_LONG).show()
    }

    private fun getInterestRate(selectedRate: String): Double {
        return when (selectedRate) {
            "10%" -> 0.10
            "13%" -> 0.13
            "18%" -> 0.18
            else -> 0.0
        }
    }

    private fun getTenure(selectedLoanType: String): Int {
        return when {
            selectedLoanType.contains("2 years") -> 2
            selectedLoanType.contains("4 years") -> 4
            selectedLoanType.contains("7 years") -> 7
            else -> 0
        }
    }

    private fun calculateEMI(loanAmount: Double, interestRate: Double, tenure: Int): Double {
        if (interestRate == 0.0) {
            return loanAmount / (tenure * 12)
        }
        val r = interestRate / 12
        val n = tenure * 12
        val emi = loanAmount * r * Math.pow(1 + r, n.toDouble()) / (Math.pow(1 + r, n.toDouble()) - 1)
        return emi
    }
}
class LoanTrackerDbHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(SQL_CREATE_ENTRIES)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL(SQL_DELETE_ENTRIES)
        onCreate(db)
    }

    companion object {
        const val DATABASE_VERSION = 1
        const val DATABASE_NAME = "LoanTracker.db"
    }
}

object LoanTrackerContract {
    object LoanEntry : BaseColumns {
        const val TABLE_NAME = "loan"
        const val COLUMN_NAME = "name"
        const val COLUMN_LOAN_TYPE = "loan_type"
        const val COLUMN_LOAN_TYPE_DETAILS = "loan_type_details"
        const val COLUMN_LOAN_AMOUNT = "loan_amount"
    }
}

val SQL_CREATE_ENTRIES = "CREATE TABLE ${LoanTrackerContract.LoanEntry.TABLE_NAME} (" +
        "${BaseColumns._ID} INTEGER PRIMARY KEY," +
        "${LoanTrackerContract.LoanEntry.COLUMN_NAME} TEXT," +
        "${LoanTrackerContract.LoanEntry.COLUMN_LOAN_TYPE} TEXT," +
        "${LoanTrackerContract.LoanEntry.COLUMN_LOAN_TYPE_DETAILS} TEXT," +
        "${LoanTrackerContract.LoanEntry.COLUMN_LOAN_AMOUNT} TEXT)"

val SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS ${LoanTrackerContract.LoanEntry.TABLE_NAME}"

